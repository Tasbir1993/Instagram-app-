//
//  Login+CoreDataClass.swift
//  instagramApp
//
//  Created by Kiran Hans on 3/23/18.
//  Copyright © 2018 Kiran Hans. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Login)
public class Login: NSManagedObject {

}
