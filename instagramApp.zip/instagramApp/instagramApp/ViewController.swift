

//
//  ViewController.swift
//  instagramApp
//
//  Created by Kiran Hans on 3/23/18.
//  Copyright © 2018 Kiran Hans. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    

    @IBOutlet weak var txtUser: UITextField!
  
    @IBOutlet weak var txtPasswd: UITextField!
     let myContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
  var databaseResults = [Login]()

    @IBAction func signInbutton(_ sender: UIButton) {
        
        let tUser = txtUser.text;
        let tPasswd = txtPasswd.text;
        // create a new user
       
        // create a new user
        let user = Login(context: self.myContext)
        user.loginName = tUser
        user.loginpasswd = tPasswd
        
        // save the user to the database
        saveData()
        
        // check for fields
        if(txtUser.text == "" || txtPasswd.text == "")
        {
            
            
            let alert = UIAlertController(title: "Error Message", message: "All Fields are required", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
            
        }
        let request : NSFetchRequest<Login> = Login.fetchRequest()
        
        if (txtUser.text!.isEmpty == false || txtPasswd.text!.isEmpty == false   ) {
            
            //if the person typed something in the search box,
            // then build an SQL query based on that
            let query = NSPredicate(format: "loginName == %@", txtUser.text!)
            request.predicate = query
            
        }
        
        
        
        do {
            
            // run the query
            databaseResults = try myContext.fetch(request)
            
            
            // if there are no results to your query,
            // then let the user know
            if databaseResults.count == 0 {
                txtUser.text = "No user found!"
                txtPasswd.text = "No password found!"
            }
            else {
                
                // otherwise, loop through all the results and show the names
                for u in databaseResults {
                    let name = u.loginName!
                    let pass = u.loginpasswd!
                    
                    txtUser.insertText(name + "\n")
                    txtPasswd.insertText(pass + "\n")
                }
            }
            
        }
        catch {
            print("an error occured while getting data: \(error)")
        }
        
        
    }
        
        
        
        
   
    
    @IBAction func signUpbutton(_ sender: UIButton) {
        
        
    }
    func saveData() {
        do {
            try myContext.save()
        }
        catch {
            print("an error occured while saving: \(error)")
        }
    }
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

