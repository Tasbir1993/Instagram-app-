//
//  SignUpVC.swift
//  instagramApp
//
//  Created by Kiran Hans on 3/23/18.
//  Copyright © 2018 Kiran Hans. All rights reserved.
//

import UIKit
import CoreData
class SignUpVC: UIViewController {

    @IBOutlet weak var sUname: UITextField!
    @IBOutlet weak var sPaswd: UITextField!
    @IBOutlet weak var sConfirm: UITextField!
    @IBOutlet weak var searchBox: UITextField!
    
    let myContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var databaseResults = [Login]()


    @IBAction func signUpNow(_ sender: Any) {
        let username = sUname.text;
        let userpasswd = sPaswd.text;
        let confirmPasswd = sConfirm.text;
        // check for fields
        if(sUname.text == "" || sPaswd.text == "" || sConfirm.text == "")
        {
          
                
                let alert = UIAlertController(title: "Error Message", message: "All Fields are required", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                
          
        }
        if(sPaswd.text != sConfirm.text)
        {
            let alert = UIAlertController(title: "Error Message", message: "Passwords do not match", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
            
        }
        let newuser = Login(context: self.myContext)
        newuser.loginName = sUname.text
        newuser.loginpasswd = sPaswd.text
        
        // save the user to the database
        saveData()
        
        
        
    }
    
    
   
        
       
        
       
    
    
    /*
     // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    func saveData() {
        do {
            try myContext.save()
        }
        catch {
            print("an error occured while saving: \(error)")
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
