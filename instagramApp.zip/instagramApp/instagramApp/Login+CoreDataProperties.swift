//
//  Login+CoreDataProperties.swift
//  instagramApp
//
//  Created by Kiran Hans on 3/23/18.
//  Copyright © 2018 Kiran Hans. All rights reserved.
//
//

import Foundation
import CoreData


extension Login {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Login> {
        return NSFetchRequest<Login>(entityName: "Login")
    }

    @NSManaged public var loginName: String?
    @NSManaged public var loginpasswd: String?

}
